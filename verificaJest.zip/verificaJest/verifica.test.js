const offusca = require('./verifica');

test('test offusca ciao diventa CI50', () => {
    let prova = "test";
    expect(verifica(prova)).toBe("CI50");
});

module.exports = offusca;